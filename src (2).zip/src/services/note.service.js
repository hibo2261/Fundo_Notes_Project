//import { id } from '@hapi/joi/lib/base';
import Note from '../models/note.model';


export const createNote = async (body) => {
  const note = await Note.create(body);
  return note;
}

export const updateNote = async (_id, body) => {
  const data = await Note.findByIdAndUpdate(
    {
      _id
    },
    body,
    {
      new: true
    }
  );
  return data;
};

export const getAll= async (userId)=>{
  const data = await Note.find({userId : userId, archive : false , trash : false});
  console.log("-----------------------------------------------------------",data);
  return data;
};

export const getById = async (_id,userId) => {
  const data = await Note.findById(_id,userId);
  return data;
};



//delete single note
export const deleteNote = async (id) => {
    await Note.findByIdAndDelete(id);
    return '';
  };


// Send note to trash
export const sendToTrash = async (_id, userId) => {
  try {
      const data = await Note.findByIdAndUpdate({ _id, userId: userId }, { trash: true });
      return data;
  } catch (err) {
      throw new Error(err)
  }
};

// Recover from trash
export const recoverFromTrash = async (_id, userId) => {
  try {
      const data = await Note.findByIdAndUpdate({ _id, userId: userId }, { trash: false });
      return data;
  } catch (err) {
      throw new Error(err)
  }
};


// Send note to trash
export const sendToArchive = async (_id, userId) => {
  try {
      const data = await Note.findByIdAndUpdate({ _id, userId: userId }, { archive: true });
      return data;
  } catch (err) {
      throw new Error(err)
  }
};

// Recover from trash
export const recoverFromArchive = async (_id, userId) => {
  try {
      const data = await Note.findByIdAndUpdate({ _id, userId: userId }, { archive: false });
      return data;
  } catch (err) {
      throw new Error(err)
  }
};


