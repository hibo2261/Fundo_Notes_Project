import express from 'express';
import * as noteController from '../controllers/note.controller';
import { NoteValidator } from '../validators/note.validator';
import { userAuth } from '../middlewares/auth.middleware';


const router = express.Router();


//route to create a new note
router.post('', NoteValidator, userAuth, noteController.createNote);


//route to update a note by its id
router.put('', userAuth, noteController.updateNote);


//route to get all notes
router.get('/', userAuth, noteController.getAll)


//routes to get a note by id
router.get('', userAuth, noteController.getById)


router.delete('/:_id', userAuth, noteController.deleteNote)

//rearrange the apis
//empty endpoints
//add validator to all

// send note to trash by id
router.put('/trash/:_id', userAuth, noteController.trash);

// recover from trash put
router.put('/trash/recover/:_id', userAuth, noteController.recovertrash);

// Send to archive by id
router.put('/archive/:_id', userAuth, noteController.archive);

// recover from trash put
router.put('/archive/recover/:_id', userAuth, noteController.recoverarchive);


export default router;